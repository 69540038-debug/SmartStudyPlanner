"""Smart Study Planner: Streamlit app with priority scoring and JSON persistence."""
from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path
from typing import TypedDict
from uuid import uuid4

import streamlit as st

DATA_FILE = Path(__file__).parent / "data" / "tasks.json"
MAX_STUDY_HOURS = 168


class StudyTask(TypedDict):
    id: str
    subject: str
    hours: int
    due_date: str
    difficulty: int


def load_tasks() -> list[StudyTask]:
    """Load saved tasks; older records default to difficulty 3."""
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as task_file:
            saved_tasks = json.load(task_file)
    except (json.JSONDecodeError, OSError) as error:
        raise ValueError(f"ไม่สามารถอ่านไฟล์ข้อมูลได้: {error}") from error

    if not isinstance(saved_tasks, list):
        raise ValueError("ข้อมูลในไฟล์ JSON ต้องเป็นรายการงาน")

    tasks: list[StudyTask] = []
    for row_number, item in enumerate(saved_tasks, start=1):
        if not isinstance(item, dict) or not all(
            key in item for key in ("id", "subject", "hours", "due_date")
        ):
            raise ValueError(f"งานลำดับที่ {row_number} มีข้อมูลไม่ครบ")
        if not isinstance(item["subject"], str) or not item["subject"].strip():
            raise ValueError(f"ชื่อวิชาของงานลำดับที่ {row_number} ไม่ถูกต้อง")
        if type(item["hours"]) is not int or not 1 <= item["hours"] <= MAX_STUDY_HOURS:
            raise ValueError(f"ชั่วโมงของงานลำดับที่ {row_number} ไม่ถูกต้อง")
        difficulty = item.get("difficulty", 3)
        if type(difficulty) is not int or not 1 <= difficulty <= 5:
            raise ValueError(f"ระดับความยากของงานลำดับที่ {row_number} ไม่ถูกต้อง")
        try:
            date.fromisoformat(item["due_date"])
        except (TypeError, ValueError) as error:
            raise ValueError(f"วันกำหนดส่งของงานลำดับที่ {row_number} ไม่ถูกต้อง") from error
        tasks.append({
            "id": str(item["id"]),
            "subject": item["subject"].strip(),
            "hours": item["hours"],
            "due_date": item["due_date"],
            "difficulty": difficulty,
        })
    return tasks


def save_tasks(tasks: list[StudyTask]) -> None:
    """Save to a temporary file first to avoid incomplete JSON writes."""
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary_file = DATA_FILE.with_suffix(".tmp")
    try:
        with temporary_file.open("w", encoding="utf-8") as task_file:
            json.dump(tasks, task_file, ensure_ascii=False, indent=2)
            task_file.write("\n")
        temporary_file.replace(DATA_FILE)
    except OSError as error:
        raise ValueError(f"ไม่สามารถบันทึกไฟล์ข้อมูลได้: {error}") from error


def get_due_status(due_date: date, today: date) -> tuple[str, int]:
    days_remaining = (due_date - today).days
    if days_remaining < 0:
        return "เลยกำหนด", days_remaining
    elif days_remaining <= 2:
        return "ใกล้ถึงกำหนด", days_remaining
    else:
        return "ยังมีเวลา", days_remaining


def split_into_study_sessions(total_hours: int) -> list[int]:
    sessions: list[int] = []
    remaining_hours = total_hours
    while remaining_hours > 0:
        session_hours = min(remaining_hours, 2)
        sessions.append(session_hours)
        remaining_hours -= session_hours
    return sessions


def calculate_priority(days_left: int, difficulty: int, hours: int) -> int:
    """Return a 0–100 heuristic score; overdue work ranks highest."""
    if days_left < 0:
        urgency = 50
    elif days_left <= 1:
        urgency = 40
    elif days_left <= 3:
        urgency = 30
    elif days_left <= 7:
        urgency = 20
    else:
        urgency = 10
    return min(100, urgency + difficulty * 6 + min(hours, 10) * 2)


def priority_label(score: int) -> str:
    if score >= 75:
        return "🔴 เร่งด่วนมาก"
    elif score >= 55:
        return "🟡 ควรทำเร็ว ๆ นี้"
    else:
        return "🟢 วางแผนล่วงหน้า"


def show_flash_message() -> None:
    message = st.session_state.pop("flash_message", None)
    if message:
        st.success(message)


st.set_page_config(page_title="Smart Study Planner", page_icon="📖", layout="wide")
st.title("📚 Smart Study Planner")
st.caption("วางแผนอ่านหนังสือและจัดลำดับงานอัตโนมัติด้วย Python")

try:
    tasks = load_tasks()
except ValueError as error:
    st.error(str(error))
    st.stop()

show_flash_message()
today = date.today()
total_hours = sum(task["hours"] for task in tasks)
due_soon_count = sum(
    1 for task in tasks if 0 <= (date.fromisoformat(task["due_date"]) - today).days <= 2
)
metric_tasks, metric_hours, metric_due = st.columns(3)
metric_tasks.metric("งานที่วางแผนไว้", len(tasks))
metric_hours.metric("ชั่วโมงอ่านรวม", f"{total_hours} ชม.")
metric_due.metric("ใกล้ถึงกำหนด", due_soon_count)
st.divider()

form_column, tasks_column = st.columns([0.9, 1.4], gap="large")
with form_column:
    st.subheader("➕ เพิ่มงานอ่านหนังสือ")
    with st.form("add_study_task", clear_on_submit=True):
        subject = st.text_input("ชื่อวิชา", placeholder="เช่น Python: บทที่ 1–5", max_chars=100)
        hours = st.number_input("จำนวนชั่วโมงอ่านหนังสือ", min_value=1, max_value=MAX_STUDY_HOURS, value=2, step=1)
        difficulty = st.slider("ระดับความยาก (1 = ง่าย, 5 = ยากมาก)", min_value=1, max_value=5, value=3)
        due_date = st.date_input("วันกำหนดส่ง", value=today + timedelta(days=7), format="DD/MM/YYYY")
        submitted = st.form_submit_button("เพิ่มงาน", type="primary", use_container_width=True)

    if submitted:
        if not subject.strip():
            st.warning("กรุณากรอกชื่อวิชา")
        else:
            new_task: StudyTask = {
                "id": uuid4().hex,
                "subject": subject.strip(),
                "hours": int(hours),
                "due_date": due_date.isoformat(),
                "difficulty": int(difficulty),
            }
            try:
                save_tasks([*tasks, new_task])
            except ValueError as error:
                st.error(str(error))
            else:
                st.session_state["flash_message"] = f"เพิ่มงานวิชา {new_task['subject']} แล้ว"
                st.rerun()
    st.info("คะแนนความสำคัญพิจารณาจากวันครบกำหนด ความยาก และชั่วโมงที่ต้องใช้")

with tasks_column:
    st.subheader("🎯 Smart Priority — งานที่ควรทำก่อน")
    if not tasks:
        st.info("ยังไม่มีงานในรายการ เริ่มจากเพิ่มวิชาที่ต้องอ่านสอบ")
    else:
        scored_tasks = []
        for task in tasks:
            days_left = (date.fromisoformat(task["due_date"]) - today).days
            score = calculate_priority(days_left, task["difficulty"], task["hours"])
            scored_tasks.append((score, days_left, task))
        scored_tasks.sort(key=lambda row: (-row[0], row[1], row[2]["subject"].casefold()))

        for score, days_left, task in scored_tasks:
            task_due_date = date.fromisoformat(task["due_date"])
            due_status, days_remaining = get_due_status(task_due_date, today)
            sessions = split_into_study_sessions(task["hours"])
            session_summary = " + ".join(f"{session} ชม." for session in sessions)

            with st.container(border=True):
                title_column, action_column = st.columns([4, 1])
                with title_column:
                    st.markdown(f"#### {task['subject']}")
                    st.write(f"**{priority_label(score)}** — คะแนน {score}/100")
                    st.progress(score / 100)
                with action_column:
                    if st.button("ลบ", key=f"delete_{task['id']}", use_container_width=True):
                        remaining_tasks = [item for item in tasks if item["id"] != task["id"]]
                        try:
                            save_tasks(remaining_tasks)
                        except ValueError as error:
                            st.error(str(error))
                        else:
                            st.session_state["flash_message"] = f"ลบงานวิชา {task['subject']} แล้ว"
                            st.rerun()
                st.write(f"📅 กำหนดส่ง: **{task_due_date.strftime('%d/%m/%Y')}**")
                st.write(f"📘 เวลาอ่าน: **{task['hours']} ชม.** | ความยาก: **{task['difficulty']}/5**")
                if days_remaining < 0:
                    st.error(f"{due_status} {abs(days_remaining)} วัน")
                elif days_remaining == 0:
                    st.warning("ครบกำหนดวันนี้")
                elif days_remaining <= 2:
                    st.warning(f"{due_status}อีก {days_remaining} วัน")
                else:
                    st.success(f"{due_status}อีก {days_remaining} วัน")
                st.caption(f"แนะนำแบ่งเวลา: {session_summary}")
